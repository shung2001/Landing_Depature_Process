"""워크플로에 따른 연구용 최종 OLS 선정 (공식 승인/운항 안전 판정 아님).

실행: python -B 코드/polygon/최종_OLS_선정.py
검증: python -B 코드/polygon/최종_OLS_선정.py --self-test

기존 Polygon을 건물·중심·정규화 3D 형상으로 중복 제거한다.
135도 이상인 PASS/PASS, PASS/REVIEW, REVIEW/REVIEW 쌍을 우선 탐색한다.
쌍이 없으면 조건부/부적합을 포함해 최선의 단일 후보를 반드시 배정한다.
기존 host_index를 후보 건물 소유관계로 사용하고 원본 버티포트 ID를 보존한다.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
import shapely
from pyproj import Transformer
from shapely.geometry import Polygon, Point, MultiPolygon
from 장애물접근표면 import create_ols_triangle

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / '자료/안전성/송파구'
TOL = 1e-6  # 수치적 접촉 공차(m), 운항 Separation 기준이 아님


def sample_ground(geometries, crs, dem):
    points = gpd.GeoSeries(geometries, crs=crs).representative_point().to_crs(dem.crs)
    values = []
    for value in dem.sample([(p.x, p.y) for p in points], indexes=1, masked=True):
        cell = value[0]
        values.append(np.nan if np.ma.is_masked(cell) else float(cell))
    return np.asarray(values)


def surface_plane(surface):
    xyz = np.asarray(surface.exterior.coords)[:-1]
    if xyz.shape != (3, 3) or not np.isfinite(xyz).all():
        raise ValueError('유한한 세 꼭짓점의 Polygon Z가 필요합니다.')
    origin = xyz[0, :2]
    coefficients = np.linalg.solve(np.column_stack([xyz[:, :2]-origin, np.ones(3)]), xyz[:, 2])
    return origin, coefficients


def evaluate(surface, footprints, roofs, tree):
    """교차 영역 모든 꼭짓점에서 평면고를 계산한다 (구멍/복합/선/점 포함)."""
    xy = shapely.force_2d(surface)
    origin, coefficients = surface_plane(surface)
    indices = np.asarray(tree.query(xy, predicate='intersects'), dtype=int)
    known = indices[np.isfinite(roofs[indices])]
    unknown = indices[~np.isfinite(roofs[indices])]
    clearances = []
    for index in known:
        overlap = xy.intersection(footprints[index])
        coords = shapely.get_coordinates(overlap)
        elevations = (coords-origin) @ coefficients[:2] + coefficients[2]
        clearances.append(float(elevations.min()-roofs[index]))
    values = np.asarray(clearances)
    penetrations = known[values < -TOL]
    contacts = known[np.abs(values) <= TOL]
    minimum = float(values.min()) if len(values) else None
    limiting = int(known[values.argmin()]) if len(values) else None
    return dict(result='FAIL' if len(penetrations) else 'REVIEW' if len(unknown)+len(contacts) else 'PASS',
                intersecting_buildings=len(indices), known_penetrations=len(penetrations),
                touching_buildings=len(contacts), unknown_buildings=len(unknown),
                min_clearance_m=minimum, limiting_building_row=limiting,
                unknown_building_rows=json.dumps(sorted(unknown.tolist())),
                penetration_building_rows=json.dumps(sorted(penetrations.tolist())),
                touching_building_rows=json.dumps(sorted(contacts.tolist())))


def consecutive_sectors(angles):
    """1도 샘플을 연결한다. 359→0 연속 및 360개 전체 PASS 처리."""
    accepted = {int(a) for a in angles}
    if not accepted:
        return []
    if accepted == set(range(360)):
        return [list(range(360))]
    starts = sorted(a for a in accepted if (a-1) % 360 not in accepted)
    groups = []
    for start in starts:
        group, angle = [], start
        while angle in accepted:
            group.append(angle)
            angle = (angle+1) % 360
        groups.append(group)
    return groups


def check_inputs(summary, candidate_dir):
    """서로 다른 ID는 같은 좌표여도 병합하지 않고 각 ID의 모든 후보 속성을 확인."""
    if summary.id.duplicated().any() or summary.empty:
        raise ValueError('요약표의 버티포트 ID는 고유해야 합니다.')
    numeric = summary[['longitude', 'latitude', 'agl_m', 'ground_z_m', 'apex_z_m', 'ols_slope_deg']].to_numpy(float)
    if not np.isfinite(numeric).all() or not (summary.agl_m > 0).all():
        raise ValueError('유효한 중심점과 시작 높이가 필요합니다.')
    if not np.allclose(summary.ols_slope_deg, 8) or not np.allclose(summary.apex_z_m, summary.ground_z_m+summary.agl_m):
        raise ValueError('현재 실행은 기존 8도/DEM+AGL 설계를 요구합니다.')
    for row in summary.itertuples():
        path = candidate_dir / str(int(row.id)) / f'Polygon_{int(row.id)}.shp'
        if not path.exists():
            if row.polygon_count == 0:
                continue
            raise FileNotFoundError(path)
        frame = gpd.read_file(path)
        expected = dict(heli_id=row.id, apex_lon=row.longitude, apex_lat=row.latitude,
                        apex_agl=row.agl_m, ground_z=row.ground_z_m, apex_z=row.apex_z_m,
                        height_m=1000, width_m=573, slope_deg=8)
        for field, value in expected.items():
            if not np.allclose(pd.to_numeric(frame[field], errors='raise'), value, rtol=0, atol=1e-6):
                raise ValueError(f'{path}: {field} 불일치')
        if not frame.z_ref.eq('DEM+AGL').all():
            raise ValueError(f'{path}: 높이 기준 불일치')


def add_tables(path, tables):
    """비공간 표도 GeoPackage attributes로 등록하여 QGIS에서 읽을 수 있게 한다."""
    with sqlite3.connect(path) as connection:
        for name, frame in tables.items():
            frame.to_sql(name, connection, if_exists='replace', index=False)
            connection.execute('DELETE FROM gpkg_contents WHERE table_name=?', (name,))
            connection.execute("INSERT INTO gpkg_contents(table_name,data_type,identifier,description,last_change) VALUES (?, 'attributes', ?, '', ?)",
                               (name, name, datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%fZ')))


def write_layer(records, path, layer, geometry_type):
    import pyogrio
    if records:
        frame = gpd.GeoDataFrame(records, crs=5186)
    else:
        frame = gpd.GeoDataFrame({'vp_id': pd.Series(dtype='int64'), 'geometry': gpd.GeoSeries([], crs=5186)}, crs=5186)
    pyogrio.write_dataframe(frame, path, layer=layer, driver='GPKG', geometry_type=geometry_type)


def self_test():
    # 중심점은 높은 쪽에 있어도 footprint 경계의 낮은 표면고로 침범을 잡아야 함.
    s = Polygon([(0, 0, 10), (10, 0, 20), (0, 10, 10)])
    b = np.array([Polygon([(1, 1), (8, 1), (8, 2), (1, 2)])], dtype=object)
    result = evaluate(s, b, np.array([12.]), shapely.STRtree(b))
    assert result['result'] == 'FAIL' and np.isclose(result['min_clearance_m'], -1)
    assert evaluate(s, b, np.array([11.]), shapely.STRtree(b))['touching_buildings'] == 1
    assert evaluate(s, b, np.array([np.nan]), shapely.STRtree(b))['result'] == 'REVIEW'
    assert evaluate(s, b, np.array([9.]), shapely.STRtree(b))['result'] == 'PASS'
    far = np.array([Point(50, 50).buffer(1)], dtype=object)
    r = evaluate(s, far, np.array([np.nan]), shapely.STRtree(far))
    assert r['result'] == 'PASS' and r['min_clearance_m'] is None
    assert consecutive_sectors([358, 359, 0, 1, 20]) == [[20], [358, 359, 0, 1]]
    assert consecutive_sectors([]) == [] and len(consecutive_sectors(range(360))[0]) == 360
    # 면적이 아닌 꼭짓점만의 접촉도 평가한다.
    touch = np.array([Polygon([(10, 0), (11, 0), (11, 1)])], dtype=object)
    assert evaluate(s, touch, np.array([20.]), shapely.STRtree(touch))['result'] == 'REVIEW'
    print('SELF-TEST OK: 부분 교차, 접촉, 결측, 비중첩, 순환 sector, 점 접촉')



def angle_distance(a, b):
    return abs((a-b+180) % 360-180)


def geometry_key(record, include_owner=True):
    """링 시작점/방향을 정규화하되 좌표 반올림은 하지 않는다. Z 차이도 보존."""
    geom = record['geometry']
    definition = (record['center_x'], record['center_y'], record['z0_dem_agl_m'],
                  record['slope_deg'], record['length_m'], record['start_width_m'],
                  record['end_width_m'], record['surface_model_id'])
    return ((record['building_id'],) if include_owner else ()) + definition + (
        shapely.to_wkb(shapely.normalize(geom), output_dimension=3),)


def deduplicate(records):
    unique, mapping, keys = [], [], {}
    for record in records:
        key = geometry_key(record)
        duplicate = key in keys
        if not duplicate:
            keys[key] = record
            unique.append(record.copy())
        representative = keys[key]
        mapping.append(dict(building_id=record['building_id'], source_vp_id=record['source_vp_id'],
            original_polygon_id=record['polygon_id'], representative_polygon_id=representative['polygon_id'],
            is_duplicate=duplicate, source_file=record['source_file'], source_row=record['source_row']))
    return unique, mapping


def clearance_value(record):
    value = record['min_clearance_m']
    return float('inf') if value is None or pd.isna(value) else float(value)


def mark_near_duplicates(records, tolerance=0.01):
    """같은 설계의 1cm 이내 유사 형상은 플래그만 붙이고 제거하지 않는다."""
    matches = {r['polygon_id']: [] for r in records}
    groups = {}
    for record in records:
        key = tuple(record[k] for k in ('building_id', 'slope_deg', 'length_m',
            'start_width_m', 'end_width_m', 'surface_model_id'))
        groups.setdefault(key, []).append(record)
    for group in groups.values():
        geometries = np.array([r['geometry'] for r in group], dtype=object)
        for i, a in enumerate(group[:-1]):
            distances = shapely.hausdorff_distance(a['geometry'], geometries[i+1:])
            for j in np.flatnonzero(distances <= tolerance) + i + 1:
                b = group[int(j)]
                if abs(a['z0_dem_agl_m'] - b['z0_dem_agl_m']) <= tolerance and np.hypot(
                    a['center_x']-b['center_x'], a['center_y']-b['center_y']) <= tolerance:
                    matches[a['polygon_id']].append(b['polygon_id'])
                    matches[b['polygon_id']].append(a['polygon_id'])
    for record in records:
        record['near_duplicate_flag'] = bool(matches[record['polygon_id']])
        record['near_duplicate_polygon_ids'] = json.dumps(matches[record['polygon_id']])


def single_key(record):
    """작은 키 우선. PASS > REVIEW > FAIL, 마지막 동률은 방위각과 ID로 결정."""
    common = (record['azimuth_deg'], record['polygon_id'])
    if record['status'] == 'PASS':
        return (0, -clearance_value(record), *common)
    if record['status'] == 'REVIEW':
        return (1, record['unknown_count'], record['touching_buildings'],
                -clearance_value(record), *common)
    return (2, record['worst_penetration_m'], record['penetration_count'],
            record['unknown_count'], *common)


def choose_candidates(records):
    """단일 최적을 먼저 고정하지 않고 135도 이상 모든 조합 탐색. FAIL 포함 쌍 제외."""
    eligible = [r for r in records if r['status'] != 'FAIL']
    best, best_key = None, None
    for i, a in enumerate(eligible):
        for b in eligible[i+1:]:
            diff = angle_distance(a['azimuth_deg'], b['azimuth_deg'])
            if diff < 135:
                continue
            passes = int(a['status']=='PASS') + int(b['status']=='PASS')
            clearances = [clearance_value(a), clearance_value(b)]
            key = (2-passes, a['unknown_count']+b['unknown_count'],
                   a['touching_buildings']+b['touching_buildings'],
                   -min(clearances), -max(clearances), -diff,
                   min(a['azimuth_deg'], b['azimuth_deg']), max(a['azimuth_deg'], b['azimuth_deg']))
            if best_key is None or key < best_key:
                best, best_key = [a, b], key
    if best:
        return sorted(best, key=single_key), 'SELECTED'
    return ([min(records, key=single_key)] if records else []), 'NOT_FOUND'


def workflow_tests():
    self_test()
    def item(angle, status='PASS', clearance=10, unknown=0, worst=0, pid=None):
        return dict(azimuth_deg=angle, status=status, min_clearance_m=clearance,
                    unknown_count=unknown, touching_buildings=0, worst_penetration_m=worst,
                    penetration_count=int(worst>0), polygon_id=pid or str(angle))
    # 0도 최고 단일 후보에 고정하면 쌍을 잃는다. 90/270을 우선 선택해야 한다.
    selected, pair = choose_candidates([item(0, clearance=100), item(90), item(270)])
    assert pair=='SELECTED' and {r['azimuth_deg'] for r in selected}=={90,270}
    assert choose_candidates([item(10), item(350)])[1]=='NOT_FOUND'
    assert angle_distance(227,90)==137 and angle_distance(30,165)==135
    selected, _ = choose_candidates([item(0), item(180,'REVIEW',unknown=2)])
    assert len(selected)==2 and selected[0]['status']=='PASS'
    selected, _ = choose_candidates([item(0,'REVIEW',unknown=1), item(180,'REVIEW',unknown=1)])
    assert len(selected)==2
    selected, pair = choose_candidates([item(0,'FAIL',worst=20), item(180,'FAIL',worst=5)])
    assert len(selected)==1 and selected[0]['worst_penetration_m']==5 and pair=='NOT_FOUND'
    shape = Polygon([(0,0,10),(1,0,11),(0,1,11)])
    base = dict(building_id='A', center_x=0., center_y=0., z0_dem_agl_m=10.,
        slope_deg=8., length_m=1000., start_width_m=0., end_width_m=573.,
        surface_model_id='TEST', source_vp_id=1, source_file='test', source_row=0)
    a = dict(base, polygon_id='a', geometry=shape)
    b = dict(base, polygon_id='b', geometry=Polygon(list(shape.exterior.coords)[::-1]))
    c = dict(base, polygon_id='c', geometry=Polygon([(0,0,11),(1,0,12),(0,1,12)]))
    d = dict(a, polygon_id='d', building_id='B')
    unique, mapping = deduplicate([a,b,c,d])
    assert len(unique)==3 and mapping[1]['representative_polygon_id']=='a'
    assert geometry_key(a, False)==geometry_key(d, False)
    near = dict(a, polygon_id='near', geometry=Polygon([(0.001,0,10),(1.001,0,11),(0.001,1,11)]))
    mark_near_duplicates([a, near])
    assert a['near_duplicate_flag'] and near['near_duplicate_flag']
    print('WORKFLOW TEST OK: 쌍 우선, 135도/순환각, 조건부/부적합, 링 방향, Z/소유관계 보존')


def draw_maps(selected, owners, obstacles, out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    plt.rcParams.update({'font.family':'Malgun Gothic', 'axes.unicode_minus':False})
    fig, axes = plt.subplots(2, 4, figsize=(22, 12), squeeze=False)
    # 현재 8개보다 많으면 필요한 행 수로 확장한다.
    if len(owners)>8:
        plt.close(fig)
        fig, axes = plt.subplots(int(np.ceil(len(owners)/4)),4,figsize=(22,6*np.ceil(len(owners)/4)),squeeze=False)
    for ax, owner in zip(axes.flat, owners):
        records = [r for r in selected if r['building_id']==owner['building_id']]
        cx, cy = owner['center_x'], owner['center_y']
        geometries = [r['geometry'] for r in records]
        if geometries:
            bounds = shapely.union_all([shapely.force_2d(g) for g in geometries]).bounds
        else:
            bounds = (cx-500,cy-500,cx+500,cy+500)
        xmin,ymin,xmax,ymax = bounds
        span=max(xmax-xmin,ymax-ymin,200)
        pad=span*.08
        local=obstacles.cx[xmin-pad:xmax+pad,ymin-pad:ymax+pad]
        if len(local):
            local.plot(ax=ax,color='#e0e3e5',edgecolor='#c6cbce',linewidth=.2)
        for record in records:
            rank=record['selected_rank']
            color='#167a93' if rank==1 else '#d3861d'
            if record['status']=='FAIL':
                color='#bb2637'
            style='--' if record['status']=='REVIEW' else '-'
            x,y=shapely.force_2d(record['geometry']).exterior.xy
            ax.fill(x,y,color=color,alpha=.13)
            ax.plot(x,y,color=color,linestyle=style,linewidth=1.7,
                label=f"{rank}순위 {record['azimuth_deg']:g}° / {record['status']}")
        ax.scatter([cx],[cy],marker='*',s=60,color='black',zorder=5)
        ax.set_xlim(xmin-pad,xmax+pad); ax.set_ylim(ymin-pad,ymax+pad)
        ax.set_aspect('equal'); ax.ticklabel_format(style='plain',useOffset=False)
        ax.tick_params(labelsize=7); ax.grid(alpha=.12)
        ax.set_title(f"{owner['building_id']} / 원본 VP {owner['source_vp_ids']}",fontsize=11)
        if records:
            ax.legend(fontsize=8,loc='best')
    for ax in list(axes.flat)[len(owners):]:
        ax.set_visible(False)
    fig.suptitle('후보 건물별 최종 OLS: 1순위 청록 / 2순위 주황 / REVIEW 점선 / FAIL 빨강\nEPSG:5186 · 경사 8° · 조건부 후보는 안전성 입증 표면이 아님',fontsize=16)
    fig.tight_layout(rect=(0,0,1,.94))
    fig.savefig(out/'ols_selected_map.png',dpi=180)
    fig.savefig(out/'ols_selected_map.pdf')
    plt.close(fig)


def main():
    import shutil
    import zipfile
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--self-test', action='store_true')
    parser.add_argument('--buildings', type=Path, default=DATA/'송파구_건물_수정_update.shp')
    parser.add_argument('--dem', type=Path, default=DATA/'송파구_DEM.tif')
    parser.add_argument('--candidates', type=Path, default=ROOT/'자료/결과물/Polygon/8')
    parser.add_argument('--output', type=Path, default=DATA/'Separation_확보/최종_OLS')
    args = parser.parse_args()
    if args.self_test:
        workflow_tests(); return
    summary_path=args.candidates/'generation_summary.csv'
    summary=pd.read_csv(summary_path).sort_values('id')
    check_inputs(summary,args.candidates)
    buildings=gpd.read_file(args.buildings).to_crs(5186)
    if buildings.geometry.isna().any() or buildings.is_empty.any() or not buildings.is_valid.all():
        raise ValueError('유효하지 않거나 비어 있는 장애물 형상을 정정해야 합니다.')
    if summary.host_index.isna().any() or not summary.host_index.between(0,len(buildings)-1).all():
        raise ValueError('후보 건물 원본 host_index 매핑을 확인해야 합니다.')
    footprints=np.array(shapely.force_2d(buildings.geometry.array),dtype=object)
    tree=shapely.STRtree(footprints)
    transform=Transformer.from_crs(4326,5186,always_xy=True)
    owners=[]
    for host, group in summary.groupby('host_index',sort=True):
        vp=next(group.itertuples())
        # 동일 물리 건물에 서로 다른 중심점이 있으면 중심점을 하나로 합치지 않는다.
        centers=group[['longitude','latitude','apex_z_m']].drop_duplicates()
        if len(centers)!=1:
            raise ValueError(f'host {host}: 서로 다른 중심/높이의 설계 그룹을 별도로 정의해야 합니다.')
        x,y=transform.transform(vp.longitude,vp.latitude)
        distance=Point(x,y).distance(footprints[int(host)])
        owners.append(dict(building_id=f'HOST_{int(host)}',host_source_row=int(host),
            source_vp_ids=json.dumps(group.id.astype(int).tolist()),center_x=x,center_y=y,
            z0_dem_agl_m=float(vp.apex_z_m),current_host_distance_m=distance,
            source_host_distance_m=float(vp.host_distance_m),
            owner_mapping_note='generation_summary host_index 소유관계 보존; 현 형상 거리 재검증 수치 참조',
            geometry=footprints[int(host)]))
    raw,source_files=[],[summary_path]
    for vp in summary.itertuples():
        path=args.candidates/str(int(vp.id))/f'Polygon_{int(vp.id)}.shp'
        if not path.exists():
            continue
        source_files.extend(p for p in path.parent.glob(path.stem+'.*') if p.is_file())
        frame=gpd.read_file(path).to_crs(5186)
        cx,cy=transform.transform(vp.longitude,vp.latitude)
        for source_row, feature in frame.iterrows():
            surface_plane(feature.geometry)
            raw.append(dict(building_id=f'HOST_{int(vp.host_index)}',source_vp_id=int(vp.id),
                polygon_id=f'vp{int(vp.id)}_row{source_row}',source_row=int(source_row),
                source_file=str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),
                azimuth_deg=float(feature.rot_deg)%360,center_x=cx,center_y=cy,
                z0_dem_agl_m=float(feature.apex_z),slope_deg=float(feature.slope_deg),
                length_m=float(feature.height_m),start_width_m=0.,end_width_m=float(feature.width_m),
                surface_model_id='TRIANGLE_LINEAR_DEM_AGL',z_ref='DEM+AGL',generated=False,
                geometry=feature.geometry))
    unique,duplicate_map=deduplicate(raw)
    errors={}
    for owner in owners:
        if any(r['building_id']==owner['building_id'] for r in unique):
            continue
        vp=summary.loc[summary.host_index.eq(owner['host_source_row'])].iloc[0]
        try:
            generated=[]
            for angle in range(360):
                tri=create_ols_triangle(latitude=vp.latitude,longitude=vp.longitude,
                    apex_agl_m=vp.agl_m,ground_z_m=vp.ground_z_m,rotation_deg=angle,
                    horizontal_height_m=1000,base_width_m=573,slope_deg=8)
                xyz=np.asarray(tri.polygon.exterior.coords)
                x,y=transform.transform(xyz[:,0],xyz[:,1])
                generated.append(dict(building_id=owner['building_id'],source_vp_id=int(vp.id),
                    polygon_id=f"generated_{owner['building_id']}_{angle}",source_row=-1,source_file='GENERATED',
                    azimuth_deg=float(angle),center_x=owner['center_x'],center_y=owner['center_y'],
                    z0_dem_agl_m=float(vp.apex_z_m),slope_deg=8.,length_m=1000.,start_width_m=0.,
                    end_width_m=573.,surface_model_id='TRIANGLE_LINEAR_DEM_AGL',z_ref='DEM+AGL',
                    generated=True,geometry=Polygon(np.column_stack([x,y,xyz[:,2]]))))
            unique.extend(generated)
        except (ValueError,TypeError) as exc:
            errors[owner['building_id']]=str(exc)
    mark_near_duplicates(unique)
    # 모든 중복 제거를 마친 뒤 장애물 평가. 소유자가 달라도 동일한 3D 표면 계산은 캐시한다.
    agl=pd.to_numeric(buildings.A16,errors='coerce').to_numpy(float)
    with rasterio.open(args.dem) as dem:
        ground=sample_ground(footprints,5186,dem)
        start_ground=sample_ground([Point(r.longitude,r.latitude) for r in summary.itertuples()],4326,dem)
    if not np.allclose(start_ground,summary.ground_z_m,rtol=0,atol=1e-5):
        raise ValueError('기존 Polygon 기준 DEM과 현재 DEM 표본이 다릅니다.')
    roofs=np.where(np.isfinite(agl)&(agl>0)&np.isfinite(ground),ground+agl,np.nan)
    cache={}
    for i,record in enumerate(unique):
        key=geometry_key(record,include_owner=False)
        if key not in cache:
            cache[key]=evaluate(record['geometry'],footprints,roofs,tree)
        stats=cache[key]
        record.update(stats,status=stats['result'],penetration_count=stats['known_penetrations'],
            unknown_count=stats['unknown_buildings'],
            worst_penetration_m=max(0.,-stats['min_clearance_m']) if stats['min_clearance_m'] is not None and stats['known_penetrations'] else 0.)
        record['surface_id']=hashlib.sha256(repr(key[:-1]).encode()+key[-1]).hexdigest()[:20]
        if (i+1)%500==0:
            print(f'평가 {i+1}/{len(unique)}',flush=True)
    selected,summaries,unresolved=[],[],[]
    for owner in owners:
        options=[r for r in unique if r['building_id']==owner['building_id']]
        chosen,pair_status=choose_candidates(options)
        diff=angle_distance(chosen[0]['azimuth_deg'],chosen[1]['azimuth_deg']) if len(chosen)==2 else None
        reasons=[]
        if not options:
            reasons.append('NO_GEOMETRY: '+errors.get(owner['building_id'],'생성 가능한 후보 없음'))
        if options and all(r['status']=='FAIL' for r in options):
            reasons.append('ALL_CANDIDATES_FAIL')
        if any(r['status']=='REVIEW' for r in chosen):
            reasons.append('DATA_REVIEW')
        if any(r['unknown_count']>0 for r in chosen):
            reasons.append('UNKNOWN_OBSTACLE_HEIGHT')
        if any(r['touching_buildings']>0 for r in chosen):
            reasons.append('SURFACE_CONTACT')
        if pair_status=='NOT_FOUND':
            reasons.append('NO_ACCEPTABLE_PAIR_135_DEG')
        if abs(owner['current_host_distance_m']-owner['source_host_distance_m'])>0.01:
            reasons.append('OWNER_DISTANCE_CHANGED_CHECK_SOURCE_MAPPING')
        for rank,item in enumerate(chosen,1):
            check=evaluate(item['geometry'],footprints,roofs,tree)
            brute=np.flatnonzero(shapely.intersects(footprints,shapely.force_2d(item['geometry'])))
            assert set(brute)==set(tree.query(shapely.force_2d(item['geometry']),predicate='intersects'))
            assert check['result']==item['status'] and check['min_clearance_m']==item['min_clearance_m']
            flag={'PASS':'PASS_SELECTED','REVIEW':'CONDITIONAL_REVIEW','FAIL':'UNSAFE_CANDIDATE'}[item['status']]
            selected.append(dict(item,selected_rank=rank,selection_flag=flag,
                pair_angle_diff_deg=diff,pair_status=pair_status,revalidated=True,
                source_vp_ids=owner['source_vp_ids']))
        counts=pd.Series([r['status'] for r in options],dtype=str).value_counts()
        summary_row=dict(building_id=owner['building_id'],source_vp_ids=owner['source_vp_ids'],
            host_source_row=owner['host_source_row'],raw_candidate_count=sum(r['building_id']==owner['building_id'] for r in raw),
            unique_candidate_count=len(options),generated_count=sum(r['generated'] for r in options),
            pass_count=int(counts.get('PASS',0)),review_count=int(counts.get('REVIEW',0)),fail_count=int(counts.get('FAIL',0)),
            selected_count=len(chosen),rank1_polygon_id=chosen[0]['polygon_id'] if chosen else None,
            rank1_azimuth_deg=chosen[0]['azimuth_deg'] if chosen else None,rank1_status=chosen[0]['status'] if chosen else 'NO_GEOMETRY',
            rank2_polygon_id=chosen[1]['polygon_id'] if len(chosen)==2 else None,
            rank2_azimuth_deg=chosen[1]['azimuth_deg'] if len(chosen)==2 else None,
            rank2_status=chosen[1]['status'] if len(chosen)==2 else None,pair_angle_diff_deg=diff,
            pair_status=pair_status,review_reasons='; '.join(reasons),
            current_host_distance_m=owner['current_host_distance_m'],source_host_distance_m=owner['source_host_distance_m'])
        summaries.append(summary_row)
        if reasons:
            unresolved.append(summary_row)
        print(f"{owner['building_id']}: {[(r['azimuth_deg'],r['status']) for r in chosen]} / 각도차 {diff}",flush=True)
    # 명시적 필수 검증: 소유자별 하나의 rank1, 최대 두 표면, 각도/중복/상태 보호.
    assert {r['building_id'] for r in summaries}=={r['building_id'] for r in owners}
    for owner in owners:
        chosen=[r for r in selected if r['building_id']==owner['building_id']]
        if not chosen:
            assert owner['building_id'] in errors
            continue
        assert sum(r['selected_rank']==1 for r in chosen)==1 and len(chosen) in (1,2)
        if len(chosen)==2:
            assert angle_distance(chosen[0]['azimuth_deg'],chosen[1]['azimuth_deg'])>=135
            assert all(r['status']!='FAIL' for r in chosen)
    assert len({geometry_key(r) for r in unique})==len(unique)
    assert len({geometry_key(r) for r in selected})==len(selected)
    assert len(duplicate_map)==len(raw)
    assert all(m['representative_polygon_id'] in {r['polygon_id'] for r in unique} for m in duplicate_map)
    out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=True)
    # 이전 버전 결과를 삭제하지 않고 하위 백업으로 이동하여 현재 결과와 혼동을 막는다.
    previous=[p for p in out.iterdir() if p.is_file() and p.name.startswith('ols_')]
    if previous:
        archive=out/'previous_runs'/datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        archive.mkdir(parents=True)
        for source in previous:
            if source.resolve().parent!=out:
                raise ValueError('백업 경로가 출력 폴더를 벗어났습니다.')
            shutil.move(str(source),str(archive/source.name))
    backup=out/'input_backup'
    backup.mkdir(exist_ok=True)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    workflow=Path(__file__).with_name('Vertiport_Final_OLS_Selection_Workflow.md')
    with zipfile.ZipFile(backup/f'ols_candidates_raw_{stamp}.zip','w',compression=zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(set(source_files+[workflow,Path(__file__)])):
            bundle.write(path,str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else path.name)
    def flat(records):
        return pd.DataFrame([{k:v for k,v in r.items() if k!='geometry'} for r in records])
    flat(duplicate_map).to_csv(out/'ols_duplicate_map.csv',index=False,encoding='utf-8-sig')
    flat(unique).to_csv(out/'ols_candidate_scores.csv',index=False,encoding='utf-8-sig',float_format='%.9f')
    pd.DataFrame(summaries).to_csv(out/'ols_selection_summary.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(unresolved,columns=list(summaries[0])).to_csv(out/'ols_unresolved.csv',index=False,encoding='utf-8-sig')
    unique_path=out/'ols_candidates_unique.gpkg'
    write_layer(unique,unique_path,'ols_candidates_unique','Polygon Z')
    write_layer(owners,unique_path,'candidate_buildings','Polygon')
    selected_path=out/'ols_selected_surfaces.gpkg'
    write_layer(selected,selected_path,'ols_selected_surfaces','Polygon Z')
    write_layer([r for r in selected if r['selected_rank']==1],selected_path,'ols_selected_rank1','Polygon Z')
    write_layer([r for r in selected if r['selected_rank']==2],selected_path,'ols_selected_rank2','Polygon Z')
    # 서로 다른 소유자 간에도 완전히 같은 형상은 지도에서 한 번만 표시할 전용 레이어.
    map_features={}
    for record in selected:
        key=geometry_key(record,False)
        if key not in map_features:
            map_features[key]=dict(record,owner_building_ids=record['building_id'])
        else:
            map_features[key]['owner_building_ids']+=','+record['building_id']
    write_layer(list(map_features.values()),selected_path,'ols_selected_display_unique','Polygon Z')
    write_layer([{**r,'geometry':Point(o['center_x'],o['center_y'],o['z0_dem_agl_m'])}
                 for r,o in zip(summaries,owners)],selected_path,'candidate_building_decisions','Point Z')
    metadata=dict(workflow=str(workflow),building_input=str(args.buildings.resolve()),dem=str(args.dem.resolve()),
        owner_definition='generation_summary.csv의 기존 host_index로 8개 후보 건물 그룹; 원본 16 VP 관계 보존. 현재 footprint와 기록된 host 거리 차이를 별도 검토 표기',
        dedup='동일 소유자/중심/설계 및 normalize(Polygon Z) 완전일치. 반올림 없음. 1cm 이내 유사 형상은 near_duplicate 플래그만 표시. 서로 다른 소유자 관계 유지; 공유 형상 계산 캐시 및 지도 전용 중복제거',
        design='원본 길이 1000m/끝단573m/시작0m/경사8도 유지. 문서 8:1은 예시. 진북 기준 시계방향',
        height='DEM+AGL 동일 기준으로 비교. 입력 DEM의 AMSL 수직 datum은 독립 검증되지 않았음',
        obstacle_policy='A16 AGL; 결측/0/음수 및 DEM 결측은 UNKNOWN. A17 자동 대체/host 제외 없음',
        contact=f'침범 <-{TOL} FAIL; ±{TOL}m 접촉은 REVIEW; 나머지 결측 중첩 REVIEW; 모두 없으면 PASS',
        selection='PASS/PASS > PASS/REVIEW > REVIEW/REVIEW; FAIL 포함 쌍 제외. 쌍 내 결측합/접촉합 최소, 최소여유 최대, 최대여유 최대, 각도차 최대, 작은 각도 우선. 단일 FAIL은 최악침범 최소→침범수 최소',
        no_overlap='min_clearance NULL은 교차한 유효 건물 없음; PASS 후보 비교에서 제한 장애물 없음(+infinity)으로 취급',
        fallback='기존 후보가 없는 소유자만 360개 생성. 생성 실패는 NO_GEOMETRY. 기존 자료는 선행 필터된 후보이며 모든 360방향을 새로 검색한 결과가 아님',
        uncertainty='부분 교차 전체 꼭짓점 높이 최솟값 사용; 지형/운항/측면 이격/표면간 중첩은 선정 조건 아님',
        input_raw_count=str(len(raw)),owner_unique_count=str(len(unique)),evaluated_geometry_count=str(len(cache)),
        candidate_building_count=str(len(owners)),source_vp_count=str(len(summary)),
        created_utc=datetime.now(timezone.utc).isoformat())
    tables={'selection_summary':pd.DataFrame(summaries),'run_metadata':pd.DataFrame(metadata.items(),columns=['key','value']),
            'owner_vp_mapping':summary.assign(building_id=summary.host_index.map(lambda i:f'HOST_{int(i)}')),
            'duplicate_map':pd.DataFrame(duplicate_map)}
    add_tables(unique_path,tables); add_tables(selected_path,tables)
    draw_maps(selected,owners,buildings,out)
    notes=['# 후보 건물별 최종 OLS 선정',
        f'- 원본 {len(raw)}개 → 소유 건물별 고유 후보 {len(unique)}개. 후보 건물 {len(owners)}개, 원본 VP {len(summary)}개.',
        f'- 선정 표면 {len(selected)}개. 2개 선정 건물 {sum(r["selected_count"]==2 for r in summaries)}개.',
        '- 건물별 원본 VP 관계, 원본 Polygon→대표 Polygon은 GPKG 표와 CSV에 보존.',
        '- 실선 PASS, 점선 REVIEW, 붉은색 FAIL. CONDITIONAL_REVIEW/UNSAFE_CANDIDATE는 승인된 안전 표면이 아님.',
        '- 기존 host_index에 따른 소유관계를 유지했으나 현재 footprint까지 거리와 기존 기록 거리가 다르므로 후보 건물 매핑은 추가 확인 대상.',
        '- 이전 실행 파일은 previous_runs, 원본 후보 백업은 input_backup에 보관.',
        '']
    notes.extend(f'- {k}: {v}' for k,v in metadata.items())
    (out/'ols_run_notes.md').write_text('\n'.join(notes),encoding='utf-8')
    loaded=gpd.read_file(selected_path,layer='ols_selected_surfaces')
    assert len(loaded)==len(selected) and loaded.geometry.has_z.all()
    assert set(loaded.building_id)|set(errors)=={o['building_id'] for o in owners}
    assert loaded.groupby('building_id').selected_rank.apply(lambda x:(x==1).sum()).eq(1).all()
    print(pd.DataFrame(summaries)[['building_id','source_vp_ids','selected_count','rank1_azimuth_deg','rank1_status','rank2_azimuth_deg','rank2_status','pair_angle_diff_deg']].to_string(index=False))
    print(f'완료: {out}')


if __name__ == '__main__':
    main()
