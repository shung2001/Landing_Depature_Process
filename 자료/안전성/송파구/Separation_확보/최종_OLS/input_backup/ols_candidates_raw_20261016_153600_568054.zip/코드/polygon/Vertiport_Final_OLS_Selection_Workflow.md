# 후보 건물별 최종 진입표면(OLS) 1~2개 선정 절차

> **목표**: 현재 생성된 다수의 노란색 진입표면 후보를 정리하여 **버티포트 후보 건물마다 최소 1개의 대표 OLS를 결과에 배정**하고, 가능하면 **서로 다른 방위각의 2개 OLS**를 선정합니다. 두 OLS의 방위각 차이는 **원형 최소각 기준 135° 이상**이어야 합니다.
>
> **범위**: 연구용 최종 진입표면의 중복 제거, 장애물 침범 평가, 후보 건물별 1·2순위 표면 선정, 결과 지도 생성까지만 다룹니다. STAR·IAF·FAF·접근속도·비행경로 설계는 제외합니다.

## 1. 가장 중요한 정의

**'모든 건물'은 OLS를 배정받아야 하는 `버티포트 후보 건물`을 의미합니다.** 장애물 검토에 사용하는 주변의 일반 건물 전체에 OLS를 배정하는 것이 아닙니다. 현재 보유한 원본 데이터의 해당 집합을 `candidate_buildings`로 지정합니다.

- **필수 배정 조건**: 후보 건물마다 결과 테이블에 1순위 OLS 후보를 **반드시 1개 이상** 기록합니다. 산출물에서 누락되는 건물이 없어야 합니다.
- **선호 조건**: 같은 건물에 2순위 OLS를 추가하고, 두 표면의 방위각이 **최소 135° 이상 이격**되도록 합니다. 이는 이번 연구의 설계 조건이지 일반적인 법정 OLS 기준을 뜻하지 않습니다.
- **적합성 원칙**: 실제로 장애물 침범이 없고 높이 데이터가 충분한 경우만 `PASS`입니다. 모든 방향이 `FAIL`이거나 `REVIEW`여도 **최선의 후보 1개는 조건부 배정**하되 `UNSAFE_CANDIDATE` 또는 `DATA_REVIEW`로 구분합니다. **'선정된 후보'와 '안전성이 입증된 표면'은 다릅니다.**
- **중복 제거**: 중심점과 형상이 완전히 동일한 OLS가 여러 개 생성됐다면 계산·지도에서 하나만 사용하되, 그것이 어떤 후보 건물에 속하는지에 대한 원본 매핑은 보존합니다.

## 2. 현재 지도에서 왜 겹쳐 보이는가

- 하나의 후보 건물 중심에서 수많은 방위각별 OLS를 생성했을 수 있습니다.
- 서로 다른 후보 건물의 OLS가 공간적으로 겹칠 수 있습니다. 이는 **중복 데이터가 아니라 서로 다른 설계 대상의 공간적 중첩**입니다.
- 같은 중심·같은 외곽 형상의 Polygon이 여러 피처에 반복 기록되어 있을 수 있습니다. **이 경우만 기하학적 중복**으로 봅니다.
- 2D에서 노란색 면이 겹치는 것은 곧바로 장애물 침범을 의미하지 않습니다. 충돌 검토에는 표면의 높이값이 필요합니다.

**따라서 작업은 `정확한 중복 삭제 → 건물별 그룹화 → 방위각별 평가 → 1개 필수 + 2개 우선 선정` 순으로 진행합니다.**

## 3. 입력 데이터 및 필드 설계

| 레이어 | 핵심 필드 | 역할 |
|---|---|---|
| `candidate_buildings` | `building_id`, `geometry`, `vp_center_x`, `vp_center_y`, `z0_amsl` | OLS를 배정받을 건물 목록 |
| `ols_candidates_raw` | `polygon_id`, `building_id`, `azimuth_deg`, 표면 기하, 설계 파라미터 | 기존 생성 Polygon 전체 |
| `obstacle_buildings` | `obstacle_id`, footprint, `A16`, 지표 표고, 높이 검증 여부 | 실제 침범 검토용 주변 건물 |
| `ground_dem` | DEM, 수직 기준 | 필요시 AMSL 고도 산정 |

- 좌표는 미터 단위인 **EPSG:5186** 사용을 권장합니다. 경도·위도 좌표를 거리 계산에 직접 쓰지 않습니다.
- 후보 건물과 장애물 건물 집합은 중복될 수 있지만 **역할과 ID를 명확히 구분**합니다.
- `azimuth_deg`는 모든 건물에 대해 일관된 방위각 정의(예: 격자북 기준 시계방향 0~360°)를 사용합니다. 기존 생성 코드의 정의가 다르다면 변환해야 합니다.
- `A16`이 건물 높이 **AGL**이라면 `roof_amsl = ground_amsl + A16`으로 통일합니다. 높이 미상은 0으로 치환하지 않습니다.

## 4. 1단계 — 중복 Polygon 제거 (반드시 먼저 수행)

### 4.1 어떤 Polygon을 중복으로 판단할 것인가

같은 건물·같은 설계 조건을 가진 후보 중 아래를 모두 만족하면 중복으로 볼 수 있습니다.

1. **같은 중심점**(같은 `building_id`이며 중심점 좌표 동일)
2. **동일한 XY Polygon 형상**(꼭짓점 순서가 다르더라도 면 자체가 동일)
3. **동일한 3D 표면 정의**(시작 표고, 경사, 길이, 폭, 고도 산정식 등 동일)

> **주의**: 위치와 XY 폴리곤만 같더라도 높이/경사 등 3D 정의가 다르면 삭제하지 않습니다. 서로 다른 건물에 우연히 공유된 동일 기하도 건물별 배정 관계를 잃어서는 안 됩니다.

### 4.2 권장 중복키

```text
key = (
  building_id,
  center_x, center_y,
  canonical_xy_geometry,
  z0_amsl, slope, length_m, start_width_m, end_width_m,
  surface_model_id
)
```

- `canonical_xy_geometry`: 링 시작점, 꼭짓점 나열방향 등의 차이에 영향을 받지 않도록 정규화한 형상. Shapely에서는 `normalize()` 또는 기하학적 `equals` 기반 비교로 구현할 수 있습니다.
- **완전히 동일**한 경우를 우선 제거합니다. 좌표가 미세하게 다른 *유사 중복*은 별도 플래그로만 표시하고 자동 삭제하지 않습니다.
- 단순 WKB 바이트 비교만 사용하면 기하학적으로 같은 면도 꼭짓점 순서에 따라 다르게 취급될 수 있습니다.

### 4.3 처리 방법

1. 기존 `ols_candidates_raw`는 **백업**합니다.
2. 중복 후보의 `polygon_id` 목록과 대표 `polygon_id`를 연결하는 `ols_duplicate_map.csv`를 만듭니다.
3. 중복 제거한 `ols_candidates_unique`를 생성합니다.
4. 각 `building_id`의 원본 후보 수 및 고유 후보 수를 출력합니다.
5. 후보가 0개인 건물은 건물 중심점에서 동일 설계 규칙으로 방위각 후보를 재생성합니다.

**QGIS 주의:** `중복 도형 삭제(Delete duplicate geometries)`는 속성 차이와 3D 정의를 자동으로 보호하지 못할 수 있으므로, **건물 ID와 설계 파라미터를 포함해 검증한 후** 적용하는 것이 안전합니다. 모든 후보를 일괄 Dissolve하거나 Union하지 않습니다.

## 5. 2단계 — 각 OLS의 장애물 침범 평가

연구용 표면의 조건은 기존 설정을 유지하고, 모든 후보에 동일하게 적용합니다.

| 설계 변수 | 기존 연구용 예시 |
|---|---:|
| 길이 | 1,000 m |
| 시작 폭 | 0 m |
| 끝단 전체 폭 | 573 m |
| 경사 | 8:1 (수평 8m당 높이 1m 상승) |
| 1차 방위각 탐색 | 1° 간격(필요 시 세분화) |

위 값은 **연구용 가정**입니다. 공식 OLS 규격으로 단정하지 않습니다.

모든 고도를 AMSL로 통일한 다음, 각각의 OLS 후보마다 다음을 계산합니다.

1. OLS의 XY 투영과 교차하는 **장애물 건물 footprint**를 찾습니다.
2. 교차하는 footprint 전체에서 **표면의 최저 높이**를 산정합니다(중심점만 비교하지 않음).
3. 각 건물의 `roof_amsl`과 비교하여 `clearance_m = min_surface_amsl - roof_amsl`을 계산합니다.
4. `clearance_m < 0`이면 침범, 접촉(=0)은 별도 경계/보수 검토로 분류합니다.
5. 건물 높이 결측은 `unknown_count`로 분리합니다.

각 OLS 후보의 결과:

| 항목 | 의미 |
|---|---|
| `penetration_count` | 표면을 침범하는 높이 확인 건물 수 |
| `worst_penetration_m` | 가장 심한 침범량(양수, 침범 없으면 0) |
| `min_clearance_m` | 계산된 최소 수직 여유(음수 가능) |
| `unknown_count` | 표면과 중첩되지만 높이 미확인인 건물 수 |
| `status` | `PASS` / `FAIL` / `REVIEW` |

판정 우선순위: `penetration_count > 0`이면 `FAIL`; 그렇지 않으면서 `unknown_count > 0` 또는 경계 접촉/검증 미완료면 `REVIEW`; 침범도 미확인도 없을 때만 `PASS`.

**이것은 3D 표면 침범 분석**입니다. 표면 외부의 건물에 대한 측면 이격이나 실제 항공기 운항 안전을 보증하지 않습니다.

## 6. 3단계 — 후보 건물마다 OLS 1개 필수 선정

**결과 생성 로직에서 빈 건물을 허용하지 않습니다.** 단, 부적합 후보를 `PASS`로 바꾸어서는 안 됩니다.

**1순위 우선순위(권장)**

1. `PASS` 후보가 있다면 그중 **최소 여유고가 가장 큰** OLS를 우선 선정
2. `PASS`가 없다면 `REVIEW` 후보 중 미확인 장애물이 적고 알려진 침범이 없는 후보를 `DATA_REVIEW`로 조건부 선정
3. 전부 `FAIL`이면 침범량·침범 건물 수 등을 기준으로 **가장 제약이 적은 후보** 1개를 `UNSAFE_CANDIDATE`로 남김
4. 생성 후보가 하나도 없으면 최소 1개를 **새로 생성·평가**한 후 위 규칙 적용. 데이터나 형상 생성이 불가능하면 결과에 `NO_GEOMETRY`를 명시하고 예외 보고(임의의 OLS를 가짜로 만들지 않음)

`FAIL` 사이의 순위는 우선 `worst_penetration_m`이 작은 후보, 다음으로 `penetration_count`가 작은 후보처럼 **사전에 정한 동일 규칙**을 사용합니다. 이는 탐색 우선순위일 뿐 운항 가능성 승인이 아닙니다.

## 7. 4단계 — 가능하면 두 번째 OLS 추가 (각도 ≥ 135°)

각 후보 건물에 대해 **첫 번째 OLS의 방위각 `a`**, 두 번째 OLS의 방위각 `b`를 비교합니다.

```python
angle_diff = abs((a - b + 180) % 360 - 180)
paired_ok = angle_diff >= 135  # 원형 최소각: 0~180도
```

**예시**

| 1순위 방위각 | 2순위 방위각 | 최소각 | 결과 |
|---:|---:|---:|---|
| 30° | 170° | 140° | 가능 |
| 10° | 350° | 20° | 불가 |
| 227° | 47° | 180° | 가능 |
| 227° | 90° | 137° | 가능 |

**선정 전략은 1순위를 먼저 고정하는 탐욕적 방법보다, '두 개의 조합'을 먼저 탐색하는 방식이 좋습니다.** 예를 들어 가장 여유가 큰 단일 OLS를 고정하면 135° 이상 떨어진 양호한 두 번째 OLS가 사라질 수 있습니다.

### 권장 선택 순서

1. 같은 건물의 서로 다른 고유 OLS 쌍 전체에서 `angle_diff >= 135°`인 조합을 찾습니다.
2. **둘 다 `PASS`인 쌍**이 있으면 그중 침범 없이 여유고가 큰 쌍을 우선 선정합니다.
3. 둘 다 `PASS`인 쌍이 없지만 `PASS + REVIEW`인 쌍이 있으면 **2개 조건부 후보**로 보존합니다.
4. 위의 쌍이 없으면 `REVIEW + REVIEW` 등 추가 조합도 확인하되, **실패 표면을 정상 후보로 위장하지 않습니다.**
5. 적합한 2개를 도출할 수 없으면 **가장 좋은 1개를 반드시 유지**하고 `pair_status = NOT_FOUND`로 기록합니다. 이 경우 억지로 135° 미만 쌍을 만들지 않습니다.
6. 기존 방위각 표본이 성겨서 쌍이 없으면 필요한 반대 방향(기준 방위각 ±135°~180° 부근)을 추가 생성·평가할 수 있습니다.

> **해석상의 주의**: 서로 다른 두 OLS를 선택한다고 해서 이착륙 분리가 자동으로 확보되는 것은 아닙니다. 본 단계에서는 **방위각 분리 조건만** 검토합니다. 이착륙 실제 운용 적합성은 후속 연구로 남깁니다.

## 8. 전체 알고리즘 의사코드

```python
# 아래는 실행용 완성 코드가 아니라 구현 절차를 명시한 의사코드입니다.
raw = load_ols_candidates()
unique, duplicate_map = deduplicate_by_owner_center_3d_geometry(raw)

results = []
for building in candidate_buildings:
    options = unique.filter(building_id=building.id)
    if not options:
        options = generate_and_evaluate_candidates(building)

    scored = [evaluate_3d_intrusion(option, obstacle_buildings, dem)
              for option in options]

    valid_pairs = [
        (p, q) for i, p in enumerate(scored) for q in scored[i+1:]
        if circular_angle_distance(p.azimuth_deg, q.azimuth_deg) >= 135
    ]

    selected_pair = choose_best_pair_by_quality(valid_pairs)
    if selected_pair and pair_quality_is_acceptable(selected_pair):
        selected = selected_pair
        pair_status = 'SELECTED'
    else:
        selected = [choose_best_single(scored)]  # 1개 필수
        pair_status = 'NOT_FOUND'

    for rank, item in enumerate(selected, 1):
        results.append(make_record(building.id, rank, item, pair_status))

assert all(any(row.building_id == b.id for row in results)
           for b in candidate_buildings)
```

여기서 `choose_best_pair_by_quality`는 **`PASS/PASS` > `PASS/REVIEW` > `REVIEW/REVIEW` > FAIL 포함**처럼 사용자가 정한 적합성 우선순위와 여유고·침범량을 함께 고려해야 합니다. `pair_quality_is_acceptable`은 `FAIL` 포함 조합을 자동 선정할지 여부를 통제합니다. 권장 기본값은 **`FAIL`을 포함한 쌍은 정상적인 2개 OLS 선정으로 인정하지 않는 것**입니다.

## 9. 최종 출력 파일과 필수 검증

| 산출물 | 설명 |
|---|---|
| `ols_candidates_unique.gpkg` | 중심·XY 형상·3D 정의 기준 중복 제거한 전체 후보 |
| `ols_duplicate_map.csv` | 삭제된 원본 Polygon ID → 대표 Polygon ID 매핑 |
| `ols_candidate_scores.csv` | 모든 고유 OLS의 건물 침범 평가 결과 |
| `ols_selected_surfaces.gpkg` | **건물별 우선 1개, 가능 시 2개**의 최종 연구용 OLS 후보 |
| `ols_selection_summary.csv` | 건물별 1/2개 여부, 각도 차, 판정, 검토 필요 이유 |
| `ols_unresolved.csv` | `NO_GEOMETRY`, 모든 방향 침범, 높이 결측 등 추가 검토 대상 |

`ols_selected_surfaces` 필수 필드:

```text
building_id, selected_rank, polygon_id, azimuth_deg,
status, selection_flag, penetration_count, worst_penetration_m,
min_clearance_m, unknown_count, pair_angle_diff_deg, pair_status
```

`selection_flag`는 `PASS_SELECTED`, `CONDITIONAL_REVIEW`, `UNSAFE_CANDIDATE` 중 하나로 명확히 구분합니다.

### 자동 검증 조건

- [ ] `candidate_buildings`의 모든 `building_id`가 결과 요약에 존재하는가?
- [ ] 건물별 `selected_rank=1`이 정확히 하나씩 있는가? (`NO_GEOMETRY` 예외는 별도 기록)
- [ ] 건물당 최종 출력 OLS 수가 1 또는 2개인가?
- [ ] 두 개를 선택한 건물은 **원형 최소각 ≥135°**인가?
- [ ] 동일 소유 건물·동일 중심·동일 3D 형상 중복이 최종 결과에 없는가?
- [ ] 중복 제거 이후에도 원본 ID 추적이 가능한가?
- [ ] `PASS`, `REVIEW`, `FAIL`이 뒤섞여 안전한 것으로 표현되지 않는가?
- [ ] 높이 기준 AMSL과 AGL을 혼동하지 않았는가?

## 10. QGIS 지도 표현 권장

```text
01_Input/
  candidate_buildings
  obstacle_buildings
  ols_candidates_raw                    # 원본, 숨김
02_Intermediate/
  ols_candidates_unique                 # 중복 제거, 기본 숨김
  ols_candidate_scores                  # 평가 결과
03_Output/
  ols_selected_rank1                    # 후보 건물당 1개
  ols_selected_rank2                    # 가능한 건물만 1개 추가
  ols_unresolved                        # 높이 미확인/침범 후보 강조
```

- 지도에는 전체 노란색 폴리곤을 모두 표시하지 않고 **선정된 1순위와 2순위만 표시**합니다.
- 동일 후보 건물의 1·2순위는 서로 다른 색 또는 윤곽선으로 표현합니다.
- `PASS`는 실선, `CONDITIONAL_REVIEW`는 점선, `UNSAFE_CANDIDATE`는 붉은 윤곽선처럼 **품질도 함께 표시**합니다.
- 원본 후보와 중복 매핑은 삭제하지 않고 분석 재현성을 위해 보관합니다.

## 11. 실제 진행 순서 요약

**① 후보 건물 목록 고정** → **② 기존 Polygon 중심/형상/3D 정의 기준 중복 제거** → **③ 각 고유 OLS의 장애물 침범 재평가** → **④ 건물별 135° 이상 이격된 적합 쌍 우선 탐색** → **⑤ 쌍이 불가능한 건물에는 가장 나은 단일 OLS 필수 배정** → **⑥ 조건부·부적합 표면은 명확히 표시** → **⑦ 선정 표면만 QGIS 최종 레이어 출력**.

### 이번 단계의 최종 연구 질문

> **각 버티포트 후보 건물에 대해 최소 하나의 최종 진입표면 후보를 남기면서, 가능하면 방위각이 135° 이상 분리된 두 개의 진입표면을 장애물 조건에 따라 선정할 수 있는가?**

**주의:** 이 문서의 'OLS'는 기존 연구에서 생성한 **가정된 장애물 제한/진입 평가표면**을 지칭합니다. 표면 침범 검토를 거쳤더라도 실제 항공절차나 법규상 OLS 승인과 동일하지 않습니다.
